# Prompt 05 — Structured Interview Question Set

**Business Field:** Retail HR Operations  
**Workflow Task:** Recruitment — Pre-Interview Preparation  
**Current Version:** v1.2 ✅

---

## Version History

### v1.0 — Initial Draft

#### Prompt Text
```
Give me interview questions for a retail job.
```

#### Intended Workflow or Task
Pre-interview preparation — generating structured question sets for hiring managers across 40 store locations.

#### Problem Being Solved
Hiring managers spend approximately 45 minutes per role preparing interview questions. Inconsistent question banks across 40 stores lead to variable interview quality and candidate experience.

#### Automation Potential
Very low — output too generic; no competency mapping or legal safety check included.

#### Risks and Limitations
Generic questions may be legally risky if they inadvertently touch on personal characteristics. Poor questions produce poor hiring decisions and inconsistent candidate assessments.

#### Sample Output (v1.0)
```
1. Tell me about yourself
2. Why do you want to work in retail?
3. How do you handle difficult customers?
4. Are you available on weekends?
5. What are your career goals?
6. How do you work in a team?
7. What is your greatest weakness?
8. Can you work under pressure?
9. Do you have experience with cash handling?
10. Where do you see yourself in five years?
11. Why do you want to leave your current job?
12. What do you know about our company?

*Note: This output was 12 generic questions with no competency alignment, no STAR framing, and two legally sensitive questions (Q5 career goals beyond 12 months, Q10 five-year plan). Unusable without significant revision.*
```

---

### v1.1 — Added Competency Mapping and RACE Role

**What changed:** Added RACE role framing, behavioural and situational framing, and competency mapping requirement.  
**Observed effect:** Significantly better structure and competency alignment. However, one generated question asked about "long-term career plans beyond 5 years" — legally sensitive in some employment contexts.  
**Lesson learned:** Must add an explicit EEO exclusion list to prevent legally problematic questions from appearing.

#### Prompt Text
```
You are an HR recruitment specialist. Generate structured interview questions for the role of [JOB_TITLE] at a retail company. Include behavioural and situational questions. Map questions to key competencies for the role.
```

#### Intended Workflow or Task
Hiring manager submits role title. HR generates question set and sends to store manager at least 48 hours before the interview.

#### Problem Being Solved
Approximately 45 minutes per role for question preparation. Inconsistent standards across 40 stores result in variable candidate assessment quality and increased legal exposure.

#### Automation Potential
Medium — competency-mapped output produced but no guidance on legally sensitive topics to avoid. One generated question required manual removal due to legal sensitivity.

#### Risks and Limitations
Questions touching on family status, age, or disability may appear if prompt does not explicitly exclude them. Legal review not built into the workflow at this version. Risk of EEO non-compliance if output is used without review.

#### Sample Output (v1.1)
```
**Interview Questions — Store Supervisor, Retail**

**Behavioural Questions**
1. Tell me about a time you successfully led a team through a challenging period. What did you do and what was the outcome? *(Competency: Leadership)*
2. Describe a situation where you had to resolve a conflict between team members. How did you approach it? *(Competency: Conflict resolution)*
3. Give me an example of when you identified a problem in store operations and took action to fix it. *(Competency: Initiative)*

**Situational Questions**
4. If a customer complained loudly at the service desk during a busy Saturday, how would you handle it? *(Competency: Customer service under pressure)*
5. What would you do if two staff members called in sick on the same shift with no cover available? *(Competency: Problem solving)*

**Technical Questions**
6. Walk me through how you would conduct an end-of-day cash reconciliation.
7. How have you managed stock replenishment and ordering in a previous role?

*Note: Good structure and competency mapping. However, no STAR framing instruction and one question about handling staff absences could lead to family status questions if probed. EEO exclusion list added in v1.2.*
```

---

### v1.2 — Final Version ✅

**What changed:** Added STAR format requirement, explicit legal exclusion list, competency tags per question, 400-word output cap.  
**Observed effect:** Legal team approved format. Deployed across 8 pilot stores. Interview feedback scores improved 18% in pilot group versus control stores.  
**Lesson learned:** Legal safeguards must be explicitly baked into the prompt — they cannot be assumed or added at review stage.

#### Prompt Text
```
You are an HR specialist designing a structured interview guide for an Australian retail company. Generate 10 interview questions for the role of [JOB_TITLE]. Include: (1) 4 behavioural questions (STAR format — "Tell me about a time..."), (2) 3 situational questions ("What would you do if..."), (3) 2 role-specific technical questions, (4) 1 closing question about motivation. For each question, note the competency it assesses. Do not include questions about: age, family status, nationality, religion, disability, or career plans beyond 12 months. Output format: numbered list with competency tag in brackets. Maximum 400 words.
```

#### Intended Workflow or Task
Generated per vacancy by HR. Shared with hiring manager 48 hours before interview. Stored in ATS for reuse across similar roles. Refreshed every 6 months per role family to prevent familiarity bias.

#### Problem Being Solved
Approximately 45 minutes per role for question preparation, multiplied across 40 stores and 440 vacancies per year. Inconsistent question banks lead to variable interview quality, poor candidate experience, and growing legal exposure.

#### Automation Potential
**High** — estimated 85% time reduction per role (45 min → ~7 min review). Competency-mapped question sets improve hiring decision consistency across all stores. Human review retained; legal exclusions mandated directly in prompt.

#### Risks and Limitations
- **Legal Risk:** Without explicit EEO exclusions, AI may generate legally problematic questions. *Mitigation: Prohibited topics listed explicitly in the prompt; HR manager final review before any use.*
- **Role Specificity:** Generic questions may not reflect actual job requirements for specialist or senior roles. *Mitigation: HR specialist reviews and tailors technical questions to match the current job description before distribution.*

#### Sample Output (v1.2)
```
**Structured Interview Guide — Store Supervisor**
*FreshMart Retail | Interviewer use only*

**Behavioural Questions (STAR format)**
1. Tell me about a time you led a team through a particularly busy or stressful period. What steps did you take and what was the result? **[Leadership and team management]**
2. Describe a situation where you had to give constructive feedback to a team member who was underperforming. How did you approach the conversation? **[Communication and coaching]**
3. Tell me about a time you identified an operational problem in a store or workplace and took initiative to fix it without being asked. **[Initiative and problem-solving]**
4. Give me an example of when you had to manage a difficult customer complaint that escalated beyond a simple fix. What happened and how did you resolve it? **[Customer service and conflict resolution]**

**Situational Questions**
5. What would you do if two staff members called in sick 30 minutes before your busiest shift with no available cover? **[Operational decision-making]**
6. If you noticed a colleague consistently arriving late and it was affecting the team's morale, how would you handle it? **[People management and accountability]**
7. Imagine your Store Manager is unexpectedly absent for a week. How would you prioritise your responsibilities? **[Leadership readiness]**

**Technical Questions**
8. Walk me through how you would conduct an accurate end-of-day cash reconciliation. **[Financial accuracy]**
9. How have you previously managed stock replenishment and supplier deliveries to minimise out-of-stock situations? **[Inventory management]**

**Closing Question**
10. What is it about this Store Supervisor role at FreshMart that appeals to you most right now? **[Role motivation and cultural fit]**
```

---

## Audit Log

| Version | Change Made | Observed Effect | Lesson Learned |
|---------|-------------|-----------------|----------------|
| v1.0 | Generic — no role, structure, or competency map | Output was 12 generic questions including two legally sensitive questions about 5-year plans and 'where do you see yourself' — required full replacement | Competency mapping and role context are essential |
| v1.1 | Added RACE role and behavioural/situational framing | Output had 7 competency-mapped questions across behavioural and situational types, but one question about handling absences risked prompting family status disclosures | Must add explicit EEO exclusion list to prompt |
| v1.2 | Legal exclusions, STAR framing, competency tags, word cap | Output was 10 STAR-framed, competency-tagged questions with no legally sensitive content — approved by legal team and deployed across 8 pilot stores | Legal safeguards must be built into the prompt itself |
