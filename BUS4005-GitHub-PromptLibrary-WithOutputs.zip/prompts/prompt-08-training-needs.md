# Prompt 08 — Training Needs Analysis Summary

**Business Field:** Retail HR Operations  
**Workflow Task:** Learning and Development Planning  
**Current Version:** v1.2 ✅

---

## Version History

### v1.0 — Initial Draft

#### Prompt Text
```
Identify training needs for retail staff.
```

#### Intended Workflow or Task
Annual L&D planning — identifying skill gaps to inform the training budget and calendar for the coming year across all 40 stores.

#### Problem Being Solved
L&D coordinator spends approximately 2 hours per team synthesising training needs from manager feedback forms. This occurs quarterly across 40 stores — approximately 320 hours per year.

#### Automation Potential
Very low — no data input provided; AI generates generic training topics entirely disconnected from actual team needs.

#### Risks and Limitations
Generic training recommendations waste budget on low-priority topics. No connection to real performance data. Output could lead to misdirected investment in irrelevant programs.

#### Sample Output (v1.0)
```
Retail staff typically need training in the following areas:
1. Customer service skills
2. Product knowledge
3. Cash handling and POS systems
4. Visual merchandising
5. Health and safety
6. Communication skills
7. Time management
8. Teamwork and collaboration

Regular training in these areas will help improve staff performance and customer satisfaction.
```

---

### v1.1 — Added Structured Input and RACE Role

**What changed:** Added RACE role framing, structured manager feedback as input, and a recommendation with justification requirement.  
**Observed effect:** Useful and relevant output produced from real data. However, L&D manager noted the absence of business impact framing — without it, the output was not suitable for executive budget approval submissions.  
**Lesson learned:** Add business impact framing to make recommendations actionable for senior leadership and budget decision-makers.

#### Prompt Text
```
You are an L&D specialist. Based on the following manager feedback, identify the top training needs for the [TEAM] team at [STORE_NAME]. Feedback: [MANAGER_FEEDBACK]. Recommend training priorities and justify each.
```

#### Intended Workflow or Task
L&D coordinator inputs manager feedback after quarterly reviews. AI identifies patterns and recommends priorities for inclusion in HR planning and budget requests.

#### Problem Being Solved
2 hours per store per quarter across 40 stores equals 320 hours per year of manual synthesis. Training plans are often misaligned with actual skill gaps as a result of limited analysis capacity.

#### Automation Potential
Medium — useful output from real data but no business impact language to support budget approval. Recommendations useful internally but not ready for executive audience without significant rewriting.

#### Risks and Limitations
Recommendations may reflect what managers report rather than actual evidence-based performance gaps. AI cannot distinguish between perception and measurable performance data. Output not yet suitable for budget submission without further development.

#### Sample Output (v1.1)
```
**Training Needs Analysis — Customer Service Team, FreshMart Fitzroy**

**Priority 1: Complaint Handling and De-escalation Skills**
The 20% increase in escalated complaints this quarter indicates a clear gap in frontline complaint resolution capability. Staff are escalating issues to management that should be resolvable at the first point of contact. A half-day complaint handling workshop would address this gap and reduce the management burden of routine escalations.

**Priority 2: POS System Proficiency**
Four transaction errors in March linked to the new POS system indicate insufficient initial training at rollout. A structured 2-hour refresher session using real transaction scenarios would rebuild confidence and reduce error rates quickly.

**Priority 3: Team Communication**
While communication has improved since the last review, this is noted as a positive trend to maintain rather than a remediated issue. Consider lightweight team meeting structures to sustain this improvement.

*Note: Solid analysis from real data. However, no business impact quantification per priority (cost, risk, time) and no recommended training format or effort estimate. These were added in v1.2.*
```

---

### v1.2 — Final Version ✅

**What changed:** Added business impact per priority, recommended training format, effort estimate in hours, anonymisation instruction, and 350-word cap.  
**Observed effect:** GM People and Culture used the first quarterly output directly for budget approval. Approved in a single meeting versus the previous multi-week process.  
**Lesson learned:** Business impact framing transforms AI summaries into decision-ready documents that senior leadership can act on directly.

#### Prompt Text
```
You are an L&D specialist preparing a training needs analysis for a retail management team. Using the performance feedback provided, identify the top 3 training priorities for the [TEAM] team at [STORE_NAME] (review period: [PERIOD]). For each priority include: (1) skill gap identified, (2) evidence from feedback, (3) business impact if unaddressed (time, cost, or risk), (4) recommended training format (e.g. on-the-job coaching, online module, external course), (5) estimated effort to address in hours. Format: 3 numbered priority sections. Maximum 350 words. Tone: objective, evidence-based. Do not include individual employee names — refer to roles only.

Manager Feedback: [MANAGER_FEEDBACK]
```

#### Intended Workflow or Task
L&D coordinator inputs quarterly manager feedback for each team. AI generates training priorities summary. HR Manager and L&D lead review and validate. Output submitted to GM People and Culture with budget request attached for approval.

#### Problem Being Solved
2 hours per store per quarter across 40 stores equals 320 hours per year of manual synthesis. Poorly targeted training wastes 10–15% of the L&D budget on low-impact interventions each year — a significant cost given tight retail margins.

#### Automation Potential
**High** — estimated 75% time reduction in synthesis phase (2 hours → ~30 min review). Business impact framing makes output suitable for direct budget submission without further rewriting. Anonymisation protects individual staff data throughout.

#### Risks and Limitations
- **Input Quality Risk:** AI can only analyse the feedback provided — if manager feedback is vague or biased, training recommendations will be too. *Mitigation: HR standardises manager feedback forms to ensure structured, evidence-based input before the prompt is run.*
- **Privacy:** Manager feedback may contain identifiable information about individual staff. *Mitigation: Anonymisation instruction mandated in prompt; outputs stored in secure HR drive and never distributed beyond the HR and L&D team.*

#### Sample Output (v1.2)
```
**Training Needs Analysis — Customer Service Team, FreshMart Fitzroy**
*Review Period: January–March 2026 | Prepared for GM People and Culture*

---

**Priority 1: Customer Complaint Handling and De-escalation**

- **Skill gap:** Frontline staff are unable to resolve customer complaints at first point of contact, defaulting to escalation
- **Evidence:** Escalations to store management increased by 20% in Q1 2026 compared to Q4 2025
- **Business impact:** Each escalated complaint requires 10–15 minutes of supervisor or manager time. At current volumes, this represents approximately 8–10 hours of leadership time per month diverted from core responsibilities. Unresolved complaints also risk customer attrition and negative reviews
- **Recommended format:** Half-day external facilitated workshop (complaint handling and de-escalation techniques, role-play scenarios)
- **Estimated effort:** 4 hours training + 1 hour preparation per team member

---

**Priority 2: POS System Accuracy**

- **Skill gap:** Insufficient proficiency with the new POS system introduced in February 2026
- **Evidence:** 4 transaction errors recorded in March 2026 alone — all linked to the new system interface
- **Business impact:** Transaction errors create reconciliation discrepancies, reduce customer throughput, and expose the business to cash handling risk. Each error requires approximately 20 minutes of supervisor correction time
- **Recommended format:** On-the-job coaching — structured 2-hour refresher using live transaction scenarios during a quiet trading period
- **Estimated effort:** 2 hours per staff member; can be delivered in-store by a trained team leader

---

**Priority 3: Maintaining Improved Team Communication**

- **Skill gap:** Communication improvement noted but not yet embedded — at risk of reverting without structure
- **Evidence:** Manager feedback notes improvement since last review; no specific incidents but flagged as requiring active maintenance
- **Business impact:** Poor team communication increases error rates, reduces shift efficiency, and impacts morale — all of which contribute to turnover in a high-churn environment
- **Recommended format:** Internal — introduce a brief 10-minute team huddle at the start of each shift using a structured agenda template
- **Estimated effort:** Negligible once established; 30 minutes for team leader training on facilitation
```

---

## Audit Log

| Version | Change Made | Observed Effect | Lesson Learned |
|---------|-------------|-----------------|----------------|
| v1.0 | No data input, no structure | Output was an 8-item generic list of standard retail training topics with no connection to the actual team feedback provided — completely generic | Must provide real performance data as input |
| v1.1 | Added RACE role, structured input, justification requirement | Output identified 3 relevant priorities from the feedback with justifications, but no business impact quantification or effort estimates — not ready for budget submission | Add business impact language for executive audience |
| v1.2 | Business impact per priority, format spec, effort estimate, anonymisation | Output was 3 fully structured priorities with evidence, business impact, training format, and effort estimates — used directly by GM People and Culture for Q2 budget approval | Decision-ready framing unlocks senior leadership use |
