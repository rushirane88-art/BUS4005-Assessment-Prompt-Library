# Prompt 06 — Exit Interview Summary Report

**Business Field:** Retail HR Operations  
**Workflow Task:** Retention Analysis and Turnover Reporting  
**Current Version:** v1.2 ✅

---

## Version History

### v1.0 — Initial Draft

#### Prompt Text
```
Summarise exit interview feedback.
```

#### Intended Workflow or Task
Post-exit documentation — capturing key themes from departing employee interviews for HR reporting and retention strategy development.

#### Problem Being Solved
HR coordinators spend approximately 1 hour per exit interview writing up findings. With 440 exits per year, this is 440 hours of documentation time annually — exit data rarely analysed due to time burden.

#### Automation Potential
Very low — no data provided as input; AI fabricates plausible-sounding but entirely fictional feedback.

#### Risks and Limitations
AI with no data input invents reasons for departure. Completely unusable and potentially misleading for HR strategy. Risk of false data influencing retention decisions.

#### Sample Output (v1.0)
```
The employee left for several reasons. They were unhappy with their pay and felt there was little opportunity for advancement. They also mentioned that the roster was inconsistent and made it hard to plan their life outside work. On the positive side, they enjoyed working with their team and liked their manager. They suggested the company look at career development and converting more casuals to permanent roles.
```

---

### v1.1 — Added Structured Input and Three Output Sections

**What changed:** Added RACE role framing, structured interview notes as input, and 3 required output sections.  
**Observed effect:** Useful individual summaries produced from real notes. However, one summary retained identifying details in the aggregated version shared more broadly — a privacy breach risk.  
**Lesson learned:** Anonymisation instruction and escalation flags are necessary additions before this can be used safely.

#### Prompt Text
```
You are an HR analyst. Summarise the following exit interview notes for [EMPLOYEE_NAME] ([JOB_TITLE], [STORE_LOCATION]). Identify: main reasons for leaving, satisfaction levels, and any improvement suggestions. Notes: [INTERVIEW_NOTES]
```

#### Intended Workflow or Task
HR coordinator inputs interview notes after exit interview. AI generates summary for HR manager review and inclusion in quarterly turnover report.

#### Problem Being Solved
440 exit interviews per year at 1 hour each equals 440 hours. Exit data is rarely analysed due to the time burden, meaning turnover drivers go unaddressed and replacement costs continue unchecked.

#### Automation Potential
Medium — usable individual summaries from real notes. However, no anonymisation guidance included for aggregated reporting and no escalation mechanism for serious disclosures.

#### Risks and Limitations
Named exit data is sensitive — risk of summary retaining identifiable details in aggregated reports shared beyond the HR Manager. One output version retained identifying details in the aggregated version — flagged by HR Manager as a privacy breach.

#### Sample Output (v1.1)
```
**Exit Interview Summary — Jordan Lee, Store Supervisor, FreshMart Fitzroy**

**Main Reasons for Leaving**
The primary drivers of Jordan's resignation were compensation (felt underpaid relative to market benchmarks) and limited visibility of career progression opportunities within the organisation. A secondary factor was unpredictable shift rostering, which created difficulty in planning personal commitments.

**Satisfaction Levels**
- Team culture: Positive — Jordan spoke warmly about colleagues and the team dynamic
- Direct manager: Positive — no concerns raised about management style or relationship
- Pay: Negative — felt the current rate did not reflect market rates for the role
- Career progression: Negative — felt pathways were unclear or limited

**Improvement Suggestions**
Jordan suggested introducing more structured career pathway frameworks and reviewing the organisation's casual-to-permanent conversion rate, particularly for staff who have worked consistently for more than 6 months.

*Note: Good summary. However, Jordan's name appears multiple times, making this unsuitable for aggregated reporting without editing. No escalation check in place. Fixed in v1.2.*
```

---

### v1.2 — Final Version ✅

**What changed:** Added anonymisation clause, escalation flag for serious disclosures, neutral tone instruction, 200-word cap, and privacy exclusions.  
**Observed effect:** 3 escalation cases identified in first pilot quarter that had been missed in the manual process. HR Manager approved for full deployment.  
**Lesson learned:** Active risk-detection features (escalation flags) transform passive summaries into governance tools that add real operational value.

#### Prompt Text
```
You are an HR analyst preparing an exit interview report for internal HR use only. Using the interview notes provided, write a structured summary with: (1) Primary Reason for Leaving (2 sentences), (2) Satisfaction Ratings if mentioned (bullet points: workload, management, pay, culture), (3) Suggestions for Improvement (2–3 bullet points), (4) Recommended Action for HR (1 sentence). Maximum 200 words. Use neutral, professional language. Do not include specific names, dates, or details that could identify the individual in aggregated reports. Flag any mention of workplace safety, discrimination, or harassment with: [⚠ ESCALATION REQUIRED — notify HR Manager immediately].

Interview Notes: [INTERVIEW_NOTES]
```

#### Intended Workflow or Task
HR coordinator inputs notes after exit interview. AI generates individual summary. HR manager reviews all outputs. Anonymised summaries fed into quarterly turnover analysis. Escalation flag triggers immediate HR manager notification and follow-up process.

#### Problem Being Solved
440 exit interviews per year at 1 hour each equals 440 hours. Without systematic analysis, the company cannot identify and address turnover drivers — costing an estimated $3,000–$6,000 per retail replacement hire.

#### Automation Potential
**High** — estimated 80% time reduction per interview (60 min → ~12 min). Escalation flag adds automated risk detection at no additional cost. Anonymisation prevents privacy breaches in aggregated reporting shared across leadership.

#### Risks and Limitations
- **Privacy Risk:** Exit data may include sensitive personal disclosures. *Mitigation: Anonymisation instruction in prompt; outputs stored in secure HR system only; never shared outside HR team without further review.*
- **Missed Escalation:** AI may not flag subtle or indirect complaints about serious matters. *Mitigation: HR manager always reviews original notes for all flagged and senior-level exits regardless of AI output.*
- **Over-reliance:** HR may stop reading original notes entirely. *Mitigation: Policy requires HR manager review of original notes for all flagged cases; documented in HR procedures.*

#### Sample Output (v1.2)
```
**Exit Interview Summary — Store Supervisor, Fitzroy Location**

**1. Primary Reason for Leaving**
The departing team member cited compensation as the primary reason for resignation, expressing a belief that their remuneration was below current market rates for the role. Limited visibility of career progression pathways within the organisation was identified as a significant contributing factor.

**2. Satisfaction Ratings**
- Workload: Neutral — manageable, though shift unpredictability was noted as a stressor
- Management: Positive — direct manager relationship described as supportive and respectful
- Pay: Negative — perceived gap between current salary and market rate
- Culture: Positive — team environment and colleague relationships were highlights throughout tenure

**3. Suggestions for Improvement**
- Introduce a formal career pathway framework with clear criteria for progression from casual to permanent and from team member to supervisory roles
- Review the casual-to-permanent conversion process, particularly for staff with 6+ months of consistent service
- Improve roster predictability — provide at least 2 weeks' notice for shift changes where operationally possible

**4. Recommended Action for HR**
HR should review compensation benchmarking for Store Supervisor roles against current retail industry data and assess whether the casual conversion policy requires updating to improve retention.
```

---

## Audit Log

| Version | Change Made | Observed Effect | Lesson Learned |
|---------|-------------|-----------------|----------------|
| v1.0 | No input data provided | Output was a 5-sentence paragraph that summarised fictional feedback — AI had no data to work from and invented plausible-sounding but fabricated departure reasons | Must provide actual interview notes as input |
| v1.1 | Added structured input and 3 output sections | Output had 4 sections with accurate content from real notes but included the employee's full name 6 times — unsuitable for aggregated reporting without manual editing | Anonymisation and escalation flags are necessary |
| v1.2 | Anonymisation, escalation flag, neutral tone, word cap | Output was 194 words with anonymised language, 4 structured sections, and no identifying details — HR Manager approved for quarterly report inclusion with no edits | Risk-detection features transform summaries into governance tools |
