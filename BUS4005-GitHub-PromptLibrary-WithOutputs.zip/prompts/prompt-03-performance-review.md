# Prompt 03 — Performance Review Summary

**Business Field:** Retail HR Operations  
**Workflow Task:** Annual Performance Documentation  
**Current Version:** v1.2 ✅

---

## Version History

### v1.0 — Initial Draft

#### Prompt Text
```
Summarise an employee performance review.
```

#### Intended Workflow or Task
Post-review documentation step — manager completes review, HR drafts formal summary for the employee file.

#### Problem Being Solved
Managers spend approximately 90 minutes per annual review writing summaries. With 800 staff on annual review cycles, this is 1,200 hours per year of management time.

#### Automation Potential
Very low — no context provided; output is meaningless without real performance data.

#### Risks and Limitations
AI may invent performance data with no safeguard in place. Completely unusable as a business document. Risk of fabricated achievements or development areas being included.

#### Sample Output (v1.0)
```
The employee has performed well this year. They met their targets and showed good teamwork. There are some areas for improvement, particularly around communication and time management. Overall, they are a valued member of the team and we look forward to their continued contribution.

Recommended rating: Meets Expectations.
```

---

### v1.1 — Added Structured Input and RACE Role

**What changed:** Added RACE role framing, structured manager notes as input, and 3 required output sections including a rating recommendation.  
**Observed effect:** Usable draft produced from real data. However, HR manager flagged the automated rating recommendation as too prescriptive and potentially dangerous.  
**Lesson learned:** Remove AI from rating decisions entirely — keep it as a drafting tool only.

#### Prompt Text
```
You are an HR business partner. Based on the following performance notes for [EMPLOYEE_NAME] ([JOB_TITLE]), write a professional performance review summary: [MANAGER_NOTES]. Include: key achievements, areas for development, and recommended rating.
```

#### Intended Workflow or Task
Manager submits review notes via HR portal. Prompt takes notes as input and generates draft summary. HR partner reviews before sharing with employee.

#### Problem Being Solved
Managers spend approximately 90 minutes per annual review on documentation. At 800 staff, this is 1,200 hours per year — 30 FTE weeks of managerial time diverted from team leadership.

#### Automation Potential
Medium — structured output from real input. However, the automated rating recommendation is risky and may conflict with manager judgement.

#### Risks and Limitations
AI rating recommendation may conflict with manager judgement and be adopted without proper review. Employee data is sensitive and requires careful handling. Risk of cultural or gender bias in language if not reviewed carefully.

#### Sample Output (v1.1)
```
**Performance Review Summary — Jordan Lee, Store Supervisor**

**Key Achievements**
Jordan has delivered a strong quarter, consistently exceeding sales targets by 12% and maintaining excellent customer satisfaction scores of 4.8 out of 5. Their leadership capability has been a real highlight, particularly their willingness to mentor new casual staff — two team members in particular have benefited significantly from Jordan's guidance and support.

**Areas for Development**
Inventory management remains an area requiring focused attention. Three stock-ordering errors were recorded during February, which impacted shelf availability during peak trading periods. Jordan would benefit from a structured refresher on our inventory systems and ordering protocols to build confidence and reduce error rates in this area.

**Recommended Rating**
Based on the above, I would recommend a rating of Exceeds Expectations, noting that the inventory management issue should be monitored closely in the next review period.

*Note: The rating recommendation was flagged by the HR Manager as inappropriate — this decision should rest with the manager, not the AI. Removed in v1.2.*
```

---

### v1.2 — Final Version ✅

**What changed:** Removed rating recommendation, added review period field, added explicit privacy exclusions, set 280-word cap.  
**Observed effect:** HR Manager approved format for use. Output used directly in 12 pilot reviews with minor edits only.  
**Lesson learned:** AI should draft, not decide — especially on sensitive HR matters like performance ratings.

#### Prompt Text
```
You are an HR business partner. Using the manager's performance notes below, draft a professional, balanced performance review summary for [EMPLOYEE_NAME] ([JOB_TITLE]) covering the review period [PERIOD]. Structure the output: (1) Summary of Performance (3 sentences), (2) Key Achievements (3 bullet points with evidence), (3) Development Areas (2 areas with recommended actions), (4) Suggested Focus for Next Period (2 sentences). Do not recommend a performance rating — this is the manager's decision. Maximum 280 words. Tone: professional, constructive, specific. Do not include salary, disciplinary history, or personal details.

Manager Notes: [MANAGER_NOTES]
```

#### Intended Workflow or Task
Triggered after manager completes review form in HR portal. HR business partner provides manager notes as input, reviews AI draft, and shares with employee only after manager approval.

#### Problem Being Solved
Managers spend approximately 90 minutes per annual review on documentation. At 800 staff, this is 1,200 hours per year — equivalent to 30 FTE weeks of management time per review cycle with no strategic value.

#### Automation Potential
**High** — estimated 70% time reduction per review (90 min → ~25 min). Rating decision retained entirely with manager. Human review mandatory before sharing with employee.

#### Risks and Limitations
- **Fabrication Risk:** If manager notes are thin, AI may over-interpret or invent achievements. *Mitigation: HR partner cross-checks all claims against source notes before use.*
- **Privacy:** Employee performance data is sensitive. Notes must not include disciplinary history, health information, or personal circumstances. Pre-prompt data scrub required.
- **Bias:** AI may introduce cultural or gender bias in phrasing. *Mitigation: HR partner reviews tone and language before distribution to employee.*

#### Sample Output (v1.2)
```
**Performance Review Summary**
**Employee:** Jordan Lee | **Role:** Store Supervisor | **Period:** January–March 2026

**1. Summary of Performance**
Jordan has delivered a consistently strong performance across the January–March 2026 quarter, demonstrating clear strengths in customer engagement and team leadership. Sales results significantly exceeded targets, supported by high customer satisfaction scores. A development focus on inventory management processes is recommended to ensure well-rounded performance going into the next review period.

**2. Key Achievements**
- Exceeded quarterly sales targets by 12%, contributing directly to store revenue growth in a competitive trading period
- Maintained a customer satisfaction score of 4.8/5 — the highest in the store this quarter — reflecting exceptional service delivery
- Proactively mentored two new casual team members, both of whom have integrated successfully into the team and are performing to standard ahead of schedule

**3. Development Areas**
- **Inventory management accuracy:** Three stock-ordering errors were recorded in February, resulting in brief shelf availability gaps. Recommended action: complete a targeted inventory systems refresher (available via the L&D portal) and introduce a double-check process for orders over $500.
- **Process adherence under pressure:** Errors occurred during high-volume trading periods, suggesting additional support may be needed when workload peaks. Recommended action: discuss workload prioritisation strategies with Store Manager during regular 1:1 sessions.

**4. Suggested Focus for Next Period**
Jordan should prioritise building confidence and accuracy in inventory management systems, with a target of zero stock-ordering errors in Q2 2026. Continued development of leadership skills — particularly delegation and workload management — will support Jordan's readiness for progression to a more senior role.
```

---

## Audit Log

| Version | Change Made | Observed Effect | Lesson Learned |
|---------|-------------|-----------------|----------------|
| v1.0 | No input data, no structure | Output was a 4-sentence generic paragraph with an invented 'Meets Expectations' rating and no specific data — completely unusable | Performance prompts need real data as input |
| v1.1 | Added RACE, structured input, rating section | Output had 3 sections and referenced actual notes, but included a rating recommendation that HR Manager flagged as inappropriate for AI to determine | Remove AI from rating decisions entirely |
| v1.2 | Removed rating, privacy exclusions, word cap | Output was 272 words with 4 structured sections, evidence-based achievements, and no rating — HR Manager approved for distribution with zero edits in 12 pilot reviews | AI drafts, humans decide on sensitive matters |
