# Prompt 01 — Welcome Email: New Hire Onboarding

**Business Field:** Retail HR Operations  
**Workflow Task:** HR Onboarding Communication  
**Current Version:** v1.2 ✅

---

## Version History

### v1.0 — Initial Draft

#### Prompt Text
```
Write a welcome email for a new employee.
```

#### Intended Workflow or Task
Step 1 of the onboarding sequence — sent to new hire once contract is signed.

#### Problem Being Solved
HR coordinators spend approximately 45 minutes per hire drafting welcome emails manually. At 55% annual turnover across 800 staff, this recurs roughly 440 times per year — approximately 330 hours of coordinator time annually.

#### Automation Potential
Low — output too generic to use without a full rewrite. Human rewrite time approximately 40 minutes per email.

#### Risks and Limitations
Minimal personalisation means low trust from the new hire. No governance issue but no meaningful time saving is achieved. Risk of tone misalignment with company brand.

#### Sample Output (v1.0)
```
Subject: Welcome to the Team!

Dear New Employee,

Welcome to our company! We are excited to have you join our team. Please report to your manager on your first day and they will show you around and get you set up.

If you have any questions, feel free to reach out to HR.

Best regards,
The HR Team
```

---

### v1.1 — Added RACE Framework and Section Structure

**What changed:** Added RACE role framing, specified business context, and listed 4 required sections.  
**Observed effect:** Tone improved significantly; output structure more consistent. However emails were sometimes 400+ words — too long for a welcome message.  
**Lesson learned:** Output format constraints (word limit, excluded content) are essential for business-ready outputs.

#### Prompt Text
```
You are an HR onboarding specialist at a mid-size Australian retail company. Write a warm, professional welcome email for a new [JOB_TITLE] joining [STORE_NAME] on [START_DATE]. Include: a warm welcome, role overview, first-week schedule, and key contacts.
```

#### Intended Workflow or Task
Step 1 of onboarding chain — triggered when HRIS confirms new hire. HR coordinator reviews and sends within 24 hours of confirmation.

#### Problem Being Solved
HR coordinators spend approximately 45 minutes per hire drafting welcome emails. At 55% annual turnover, that is approximately 330 hours per year — equivalent to 8+ weeks of one FTE's time.

#### Automation Potential
Medium — output improved significantly but inconsistent length and no word limit. Human edit time approximately 15 minutes.

#### Risks and Limitations
RACE framework improves tone but lack of a length constraint produces variable outputs. Risk of over-length emails reducing readability. No PII included beyond name, role, and date.

#### Sample Output (v1.1)
```
Subject: Welcome to FreshMart Fitzroy, Jordan!

Dear Jordan,

We are absolutely thrilled to welcome you as our newest Store Supervisor at FreshMart Fitzroy, starting Monday, 14 April 2026!

**Your Role**
As Store Supervisor, you will play a key part in leading our retail team, ensuring exceptional customer service, and supporting daily store operations. You'll work closely with our Store Manager and broader leadership team to drive performance and maintain our high standards.

**Your First Week**
- Monday: Induction with HR, store tour, and meet the team
- Tuesday–Wednesday: Shadow our current supervisors across all departments
- Thursday: Systems training (POS, inventory, scheduling software)
- Friday: First independent shift with support available

**Key Contacts**
- Store Manager: Sarah Mitchell
- HR Coordinator: Tom Nguyen
- Area Manager: Priya Sharma

We look forward to seeing the great things you'll bring to FreshMart Fitzroy. Don't hesitate to reach out to Tom in HR on hr@freshmart.com.au if you have any questions before your start date.

Warm regards,
The FreshMart HR Team

*Note: This email was 287 words — too long, and tone was somewhat inconsistent in places.*
```

---

### v1.2 — Final Version ✅

**What changed:** Added 220-word limit, numbered section structure, explicit content exclusion (salary/contract).  
**Observed effect:** Consistent, business-ready outputs in 9 min review time. Format constraints eliminated length variability.  
**Lesson learned:** Format constraints + explicit exclusions = reliable, deployable outputs.

#### Prompt Text
```
You are an HR onboarding specialist at a mid-size Australian retail chain. Draft a warm, professional welcome email for a new [JOB_TITLE] joining [STORE_NAME] on [START_DATE]. Include: (1) warm welcome paragraph, (2) brief role overview (2 sentences), (3) first-week schedule highlights, (4) key contacts with names and roles, (5) one motivational closing sentence. Maximum 220 words. Do not include salary, contract, or payroll details.
```

#### Intended Workflow or Task
Step 1 of HR onboarding chain. Triggered automatically when new hire status confirmed in HRIS. HR coordinator reviews output, personalises if needed, and sends within 24 hours.

#### Problem Being Solved
HR coordinators spend approximately 45 minutes per hire on this task. At 55% annual turnover across 800 staff, that equates to approximately 330 hours per year — equivalent to 8+ FTE weeks of repetitive drafting with no strategic value.

#### Automation Potential
**High** — estimated 80% time reduction per hire (45 min → ~9 min review). Scalable across all 40 store locations. Human review retained before sending to catch errors or tone issues.

#### Risks and Limitations
- **Hallucination Risk:** If HRIS placeholder variables (`[JOB_TITLE]`, `[STORE_NAME]`, `[START_DATE]`) are empty or malformed, the AI may fabricate plausible-sounding but incorrect details. *Mitigation: validate all placeholders before prompt executes; add mandatory pre-send human check.*
- **Privacy:** No PII beyond name, role, and date. Do not pass salary, contract terms, or personal details into the prompt.

#### Sample Output (v1.2)
```
Subject: Welcome to FreshMart Fitzroy, Jordan!

Dear Jordan,

We're so excited to welcome you to the FreshMart family! Joining us as Store Supervisor at FreshMart Fitzroy on Monday, 14 April 2026 is a big moment, and we're here to make sure your first days are smooth and enjoyable.

As Store Supervisor, you'll lead our customer service team, support daily operations, and help maintain the high standards that FreshMart Fitzroy is known for. You'll work closely with our Store Manager and have a direct impact on both the team and customer experience.

**Your first week looks like this:**
- Monday: HR induction, store tour, meet the team
- Tuesday–Wednesday: Shadow current supervisors across departments
- Thursday: POS and inventory systems training
- Friday: First supervised independent shift

**Your key contacts:**
- Store Manager: Sarah Mitchell — sarah.mitchell@freshmart.com.au
- HR Coordinator: Tom Nguyen — hr@freshmart.com.au
- IT Helpdesk: support@freshmart.com.au

We believe great leaders grow here — and we can't wait to see what you'll achieve. Welcome aboard!

Warm regards,
Tom Nguyen
HR Coordinator, FreshMart
```

---

## Audit Log

| Version | Change Made | Observed Effect | Lesson Learned |
|---------|-------------|-----------------|----------------|
| v1.0 | Initial — broad instruction only | Output was a generic 3-sentence email with no name, no structure, and no store reference — required complete rewrite (estimated 40+ min) | Need role framing and output structure |
| v1.1 | Added RACE role + 4 section headings | Output was 287 words with improved tone and 4 sections, but exceeded ideal length by 30%+ — required editing before send | Add explicit format constraints |
| v1.2 | Word limit + exclusions + numbered structure | Output was 198 words, correctly structured with 5 numbered sections, appropriate tone, and no excluded content — sent with zero edits in pilot | Format constraints = reliable outputs |
